/*----------------------------------------*\
  256x256x256 - script.js
  @author Evrard Vincent (vincent@ogre.be)
  @Date:   2018-02-27 12:27:03
  @Last Modified time: 2018-03-21 21:05:44
\*----------------------------------------*/
//let availableLVL = (new Array(256)).fill().map((p, k)=>{k = k.toString(16);while(k.length<2) k = "0"+k;return "0x"+k});
let availableLVL = [
	"0x0b", "0x10", "0x17", "0x18", "0x19", "0x1B", "0x1D", 
	"0x19",
	"0x24", "0x26", "0x29", "0x2a", 
	"0x32", "0x35", "0x38", "0x3b", "0x3d", 
	"0x4f", 
	"0x50", "0x51", "0x56", "0x58", "0x5a", "0x5E", 
	"0x62", "0x63", "0x67", "0x69", "0x6d", "0x6F", 
	"0x71", "0x77", "0x7c", "0x7d", 
	"0x87", 
	"0x99", "0x9B", "0x9e", 
	"0xA0", "0xA2", "0xa7", "0xAB", "0xac", 
	"0xb0", "0xB1", "0xB2", "0xB4", "0xBE",
	"0xc1", "0xCE", "0xcf", 
	"0xd1", "0xd2", "0xd3", "0xd5", "0xDE", 
	"0xe0", "0xE3", "0xE5", "0xEA", 
	"0xf4", "0xf8", "0xFA"
	];
let historyLVL = [];
let failTimeout ;
let failAfter = 14000;
let scoreDom;
let totalDom;
let winDom;
let iframeDom;
let iframeWrapperDom;
let lvlDom;
let flagNext = false;
document.addEventListener("DOMContentLoaded", setup);
window.onmessage = onMessageFromLVL;

function setup(){
	lvlDom = document.getElementsByClassName("lvl")[0];
	winDom = document.getElementsByClassName("win")[0];
	scoreDom = document.getElementsByClassName("score")[0];
	totalDom = document.getElementsByClassName("total")[0];
	iframeDom = document.getElementsByTagName("IFRAME")[0];
	iframeWrapperDom = document.getElementsByClassName("wrapper")[0];
	iframeDom.onload = onLevelLoaded;
	totalDom.innerText = availableLVL.length;
	requestAnimationFrame(runAnimator);
	nextLVL();
}

function onMessageFromLVL (e){
	if(e.data == "SUCCESS" && flagNext){
		flagNext = false;
		clearTimeout(failTimeout);
		nextLVL();
	}
}

function gameOver(success){
	let anim;
	if(success){
		winDom.innerText = "YOU WIN";
		anim = function(){
			win(winDom);
		}
	}else{
		winDom.innerText = "YOU LOOSE";	
		anim = function(){
			loose(winDom);
		}
	}
	Close(anim);
}

function nextLVL(){
	let lvl = getRandomLVL();
	if(isGameOver(lvl)){
		setScore2Display();
		return gameOver(true);//with success
	}
	setLvl2Display(lvl);
	Close(function(){
		Magnify(375, scoreDom);
		setScore2Display();
		setLevel(lvl);
	});
}

function prevLVL(){
	flagNext = false;
	let lvl = getLastLVL();
	if(isGameOver(lvl)){
		setScore2Display();
		return gameOver(false);//without success
	}
	setLvl2Display(lvl);
	Close(function(){
		Minify(375, scoreDom);
		setScore2Display();
		setLevel(lvl);
	});
}

function runAnimator(){
	Animator.update();
	requestAnimationFrame(runAnimator);
}

function onLevelLoaded(){
	if(iframeDom.src && !flagNext){
		flagNext = true;
		setTimeout(function(){
			Open(function(){
				clearTimeout(failTimeout);
				failTimeout = setTimeout(prevLVL, failAfter);
			});
		}, 750);
	}
}

function isGameOver(lvl){
	return undefined == lvl;
}

function getLastLVL(){
	availableLVL.push(historyLVL.pop());
	return historyLVL[historyLVL.length-1];
}

function getRandomLVL(){
	// return level name 
	// or
	// return undefined in case of no more level
	let currentLvl = availableLVL.splice(Math.floor(Math.random() * availableLVL.length), 1)[0];
	if(undefined != currentLvl){
		historyLVL.push(currentLvl);
	}
	return currentLvl; 
}

function setLvl2Display(lvl){
	lvlDom.innerText = lvl;
}

function setScore2Display(){
	let score = historyLVL.length - 1;
	scoreDom.innerText = score>0 ? score : 0  ;
}

function setLevel(lvl){
	console.log(lvl);
	iframeDom.src = "../"+lvl+"/index.html";
}
